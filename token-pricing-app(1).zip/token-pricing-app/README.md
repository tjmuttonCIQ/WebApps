# AI Token Pricing — Azure Static Web App

A static Vite + React build of the token pricing dashboard, ready to deploy.

## Run locally

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

Outputs to `dist/`.

## Deploy to Azure Static Web Apps

You have two paths. If this is going into its own repo (recommended over folding it into
the celeste-iq.ai repo, since it has its own build), the GitHub-connected route is the
easiest to keep updated.

### Option A — GitHub-connected (auto-deploys on every push)

1. Push this folder to a new GitHub repo.
2. Azure Portal → **Create a resource** → **Static Web App**.
3. Deployment source: **GitHub** → authorize → pick the repo/branch.
4. Build presets: **Vite** (or Custom, with the values below):
   - App location: `/`
   - Api location: *(leave blank)*
   - Output location: `dist`
5. Create. Azure commits a GitHub Actions workflow into the repo — every push to that
   branch rebuilds and redeploys automatically.
6. You'll get a default `<name>.azurestaticapps.net` URL immediately. To put it on a
   subdomain (e.g. `pricing.celeste-iq.ai`), add a CNAME in Cloudflare pointing at that
   `azurestaticapps.net` hostname, then add the custom domain in the Static Web App's
   **Custom domains** blade — same pattern you're already using for celeste-iq.ai.

### Option B — CLI deploy (no GitHub Actions, good for a quick one-off)

```bash
npm install -g @azure/static-web-apps-cli
az login
az staticwebapp create \
  --name ai-token-pricing \
  --resource-group <your-resource-group> \
  --location eastus2

npm run build
swa deploy ./dist --deployment-token <token-from-the-portal>
```

The deployment token is under the resource's **Overview → Manage deployment token**
in the Azure Portal.

## Notes

- This is a static reference page — no backend, no API location needed.
- `staticwebapp.config.json` sets the SPA fallback route; it's already wired up.
- The pricing data in `src/App.jsx` is a hand-compiled snapshot (July 15, 2026).
  It won't update itself — edit the `MODELS` and `TREND` arrays and redeploy when
  you want to refresh it.
